package newpackage;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Departamento {
    private String nombreDepartamento;
    private String ubicacion;
    private ArrayList<Empleado> empleados; 
    
    public Departamento(String nombreDepartamento, String ubicacion) {
        this.nombreDepartamento = nombreDepartamento;
        this.ubicacion = ubicacion;
        this.empleados = new ArrayList<>(); 
    }

    public String getNombreDepartamento() {
        return nombreDepartamento;
    }

    public void setNombreDepartamento(String nombreDepartamento) {
        this.nombreDepartamento = nombreDepartamento;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado); 
        JOptionPane.showMessageDialog(null, "Empleado " + empleado.getNombre() + " agregado al departamento " + nombreDepartamento);
    }

    public void mostrarEmpleados() {
        StringBuilder Empleados = new StringBuilder("Empleados del departamento " + nombreDepartamento + ":\n");
        for (Empleado empleado : empleados) {
            Empleados.append("- ").append(empleado.getNombre()).append("\n");
        }
        JOptionPane.showMessageDialog(null, Empleados.toString());
    }
}
