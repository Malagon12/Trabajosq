package newpackage;

import javax.swing.JOptionPane;

public class Empleado {
    private String nombre;
    private int edad;
    private double salario;
    private String puesto;

    public Empleado(String nombre, int edad, double salario, String puesto) {
        this.nombre = nombre;
        this.edad = edad;
        this.salario = salario;
        this.puesto = puesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
      public Empleado() {
        nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado:");
        edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad del empleado:"));
        salario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado:"));
        puesto = JOptionPane.showInputDialog("Ingrese el puesto del empleado:");
    }
    public void asignarProyecto(Proyecto proyecto){
        proyecto.agregarEmpleado(this);
        JOptionPane.showMessageDialog(null, "Nombre del empleado: ");
    }
}
