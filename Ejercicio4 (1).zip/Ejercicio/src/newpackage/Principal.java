package newpackage;
public class Principal {
    public static void main(String[] args) {
            Empleado empleado1 = new Empleado();
        Empleado empleado2 = new Empleado();

        Departamento departamento = new Departamento();
        departamento.agregarEmpleado(empleado1);
        departamento.agregarEmpleado(empleado2);

        departamento.mostrarEmpleados();

        Proyecto proyecto = new Proyecto();
        empleado1.asignarProyecto(proyecto);
        empleado2.asignarProyecto(proyecto);

        proyecto.mostrarEmpleado();
    }
}
