package newpackage;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Proyecto {
   private String nombreProyecto;
   private double presupuesto;
   private String fechaInicio;
   private String fechaFin;
   private ArrayList<Empleado>empleados;

    public Proyecto(String nombreProyecto, double presupuesto, String fechaInicio, String fechaFin, ArrayList<Empleado> empleado) {
        this.nombreProyecto = nombreProyecto;
        this.presupuesto = presupuesto;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.empleados = new ArrayList<>();
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public double getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(double presupuesto) {
        this.presupuesto = presupuesto;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public ArrayList<Empleado> getEmpleado() {
        return empleados;
    }

    public void setEmpleado(ArrayList<Empleado> empleado) {
        this.empleados = empleado;
    }
        public Proyecto() {
        nombreProyecto = JOptionPane.showInputDialog("Ingrese el nombre del proyecto:");
        presupuesto = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el presupuesto del proyecto:"));
        fechaInicio = JOptionPane.showInputDialog("Ingrese la fecha de inicio del proyecto:");
        fechaFin = JOptionPane.showInputDialog("Ingrese la fecha de fin del proyecto:");
        empleados = new ArrayList<>();
    }
   public void agregarEmpleado(Empleado empleado){
     empleados.add(empleado);
     JOptionPane.showMessageDialog(null,"Empleado"+ empleado.getNombre()+ "proyecto asignado"+ nombreProyecto + "\n");
   }

   public void mostrarEmpleado(){
       StringBuilder info = new StringBuilder("Empleados asignados al proyecto " + nombreProyecto + ":\n");
       for(Empleado empleado : empleados){
            info.append("- ").append(empleado.getNombre()).append("\n");
        }
               JOptionPane.showMessageDialog(null, info.toString());

   }
}
