package newpackage;

import java.time.LocalDate;
import java.util.Date;

public class Prestamo {
  private Miembro miembro;
    private Instrumento instrumento;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucion;
    private LocalDate fechaDevolucionReal;
    private String estadoPrestamo;

    public Prestamo(Instrumento instrumento, LocalDate fechaPrestamo, LocalDate fechaDevolucion, Miembro miembro) {
        this.miembro = miembro;
        this.instrumento = instrumento;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.estadoPrestamo = "en curso";
    }

    public Miembro getMiembro() {
        return miembro;
    }

    public Instrumento getInstrumento() {
        return instrumento;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public LocalDate getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }

    public void setFechaDevolucionReal(LocalDate fechaDevolucionReal) {
        this.fechaDevolucionReal = fechaDevolucionReal;
        this.estadoPrestamo = "devuelto";
    }

    public String getEstadoPrestamo() {
        return estadoPrestamo;
    }

    public boolean isAtrasado() {
        return LocalDate.now().isAfter(fechaDevolucion);
    }

    public void mostrarInfo() {
        System.out.println("Usuario: " + miembro);
        System.out.println("Instrumento: " + instrumento.getNombre());
        System.out.println("Fecha Prestamo: " + fechaPrestamo);
        System.out.println("Fecha Devolucion: " + fechaDevolucion);
        System.out.println("Estado: " + (isAtrasado() ? "Atrasado" : "En Plazo"));
        System.out.println();
    }
}