package newpackage;

import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
public class Principal {
    private static SistemaGestionInstrumentos sistemaGestionInstrumentos = new SistemaGestionInstrumentos();

    public static void main(String[] args) {
        gestionarMenu();
    }

    public static void gestionarMenu() {
        int opcion;
        SistemaGestionInstrumentos sistema = new SistemaGestionInstrumentos();
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(
                "Menú Principal\n" +
                "1. Agregar Instrumento\n" +
                "2. Actualizar Estado de Instrumento\n" +
                "3. Actualizar Cantidad de Instrumento\n" +
                "4. Solicitar Préstamo\n" +
                "5. Registrar Devolución\n" +
                "6. Eliminar Instrumento\n" +
                "7. Generar Reporte de Instrumentos Disponibles\n" +
                "8. Generar Historial de Préstamos\n" +
                "9. Generar Reporte de Instrumentos No Devueltos a Tiempo\n" +
                "10. Generar Reporte de Uso por Grupo\n" +
                "11. Salir\n" +
                "Selecciona una opción:"
            ));

            switch (opcion) {
                case 1 :
                    sistema.agregarInstrumento();
                break;
                case 2 :
                    sistema.actualizarInstrumento();
                    break;
                case 3 :
                    sistema.actualizarCantidadInstrumento();
                    break;
                case 4 :
                    sistema.solicitarPrestamo();
                    break;
                case 5:
                    sistema.registrarDevolucionInstrumento();
                    break;
                case 6 :
                    sistema.eliminarInstrumento();
                    break;
                case 7 : 
                    sistema.generarReporteInstrumentosDisponibles();
                    break;
                case 8 :
                    sistema.generarHistorialPrestamos();
                    break;
                case 9 :
                    sistema.generarReporteInstrumentosNoDevueltosATiempo();
                    break;
                case 10 :
                    sistema.generarReporteUsoPorGrupo();
                    break;
                case 11 : JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                default : JOptionPane.showMessageDialog(null, "Opción no válida.");
            }
        } while (opcion != 11);
    }
}