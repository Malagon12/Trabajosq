
package newpackage;
import java.time.LocalDate;
import javax.swing.*;
import java.util.*;

public class SistemaGestionInstrumentos {
    private ArrayList<Instrumento> inventarioInstrumentos;
    private ArrayList<Prestamo> listaPrestamos;

    public SistemaGestionInstrumentos() {
        this.inventarioInstrumentos = new ArrayList<>();
        this.listaPrestamos = new ArrayList<>();
    }

    public String entrada(String texto) {
        return JOptionPane.showInputDialog(texto);
    }

    public void agregarInstrumento() {
        String nombre = entrada("Nombre del instrumento: ");
        for (Instrumento instrumento : inventarioInstrumentos) {
            if (instrumento.getNombre().equalsIgnoreCase(nombre)) {
                JOptionPane.showMessageDialog(null, "El instrumento ya existe.");
                return;
            }
        }
       String grupo = entrada("grupo al que pertenece el instrumento: ");
       String estado = entrada("estado del instrumento: ");
       int cantidad = Integer.parseInt(entrada("cantidad de instrumentos: "));
       
       Instrumento libro = new Instrumento(nombre, grupo, estado, cantidad);
       inventarioInstrumentos.add(libro);
       JOptionPane.showMessageDialog(null, "El instrumento ha sido registrado exitosamente");
    }

    public void eliminarInstrumento() {
      String nombre= entrada("Ingrese el nombre del libro a eliminar: ");
       boolean eliminado = inventarioInstrumentos.removeIf(instrumento-> instrumento.getNombre().equalsIgnoreCase(nombre));
       if (eliminado) {
           JOptionPane.showMessageDialog(null, "Libro elimininado!!:\n");
       }
       else {
           JOptionPane.showMessageDialog(null, "Libro NO Encontrado");
       }
   }

    public void actualizarInstrumento() {
    String nombreInstrumento = JOptionPane.showInputDialog("Ingrese el nombre del instrumento a actualizar:");

    Instrumento instrumentoEncontrado = inventarioInstrumentos.stream()
            .filter(instrumento -> instrumento.getNombre().equalsIgnoreCase(nombreInstrumento))
            .findFirst()
            .orElse(null);

    if (instrumentoEncontrado != null) {
        String nuevoNombre = JOptionPane.showInputDialog("Nuevo nombre (actual: " + instrumentoEncontrado.getNombre() + "):");
        instrumentoEncontrado.setNombre(nuevoNombre);
        JOptionPane.showMessageDialog(null, "Instrumento actualizado exitosamente!");
    } else {
        JOptionPane.showMessageDialog(null, "Instrumento no encontrado.");
    }
}
public void actualizarCantidadInstrumento() {
    String nombreInstrumento = JOptionPane.showInputDialog("Ingrese el nombre del instrumento a actualizar la cantidad:");

    Instrumento instrumentoEncontrado = inventarioInstrumentos.stream()
            .filter(instrumento -> instrumento.getNombre().equalsIgnoreCase(nombreInstrumento))
            .findFirst()
            .orElse(null);

    if (instrumentoEncontrado != null) {
        String nuevaCantidadStr = JOptionPane.showInputDialog("Ingrese la nueva cantidad (actual: " + instrumentoEncontrado.getCantidad() + "):");

        try {
            int nuevaCantidad = Integer.parseInt(nuevaCantidadStr);
            if (nuevaCantidad >= 0) {
                instrumentoEncontrado.setCantidad(nuevaCantidad);
                JOptionPane.showMessageDialog(null, "Cantidad del instrumento actualizada exitosamente!");
            } else {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero positivo.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "Instrumento no encontrado.");
    }
}
    public void solicitarPrestamo() {
  if (inventarioInstrumentos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay libros disponibles");
            return;
       }
       String nombreLibro = entrada("Ingrese el nombre del libro a prestar: ");
       Instrumento instrumentoPrestado = null;
       for(Instrumento instrumento: inventarioInstrumentos){
           if (instrumento.getNombre().equalsIgnoreCase(nombreLibro)) {
               instrumentoPrestado = instrumento;
               break;
           }
       }
       if (instrumentoPrestado==null) {
            JOptionPane.showMessageDialog(null, "Libro no encontrado");
            return;
       }
       if (instrumentoPrestado.getCantidad()<=0) {
           JOptionPane.showMessageDialog(null, "No hay ejemplares disponibles");

       }
       
       String miembro = entrada("Ingrese el nombre del usuario: ");

       Prestamo prestamo = new Prestamo(instrumentoPrestado, LocalDate.EPOCH, LocalDate.EPOCH, miembro);
       listaPrestamos.add(prestamo);
       JOptionPane.showMessageDialog(null, "Prestamo Registrado Exitosamente!!.\nFecha de Devolucion: " + prestamo.getFechaDevolucion());
   }

    public void registrarDevolucionInstrumento() {
           if (inventarioInstrumentos.isEmpty()) {
           JOptionPane.showMessageDialog(null, "No hay libros en la lista");
           return;
       }
       StringBuilder reporte = new StringBuilder();
       reporte.append("Reporte detallado de Libros Prestados: \n");
       reporte.append("----------------------------: \n");
       reporte.append("Total Titulos: ").append(inventarioInstrumentos.size()).append("\n");
        for (Prestamo prestamos : listaPrestamos) {
            reporte.append("Libro: ").append(prestamos.getInstrumento().getNombre()).append("\n");
            reporte.append("Usuario: ").append(prestamos.getMiembro()).append("\n");
            reporte.append("Fecha Prestamo: ").append(prestamos.getFechaPrestamo()).append("\n");
            reporte.append("Fecha Devolucion: ").append(prestamos.getFechaPrestamo()).append("\n");
            reporte.append("Estado: ").append(prestamos.isAtrasado() ? "Atrasado": "En plazo").append("\n\n");
        }
        JOptionPane.showMessageDialog(null, reporte.toString());
    } 


    public List<Instrumento> generarReporteInstrumentosDisponibles() {
        List<Instrumento> disponibles = new ArrayList<>();
        for (Instrumento instrumento : inventarioInstrumentos) {
            if (instrumento.estaDisponible()) {
                disponibles.add(instrumento);
            }
        }
        return disponibles;
    }

    public List<Prestamo> generarHistorialPrestamos() {
        return new ArrayList<>(listaPrestamos);
    }

    public List<Prestamo> generarReporteInstrumentosNoDevueltosATiempo() {
        List<Prestamo> noDevueltos = new ArrayList<>();
        for (Prestamo prestamo : listaPrestamos) {
            if (prestamo.isAtrasado()) {
                noDevueltos.add(prestamo);
            }
        }
        return noDevueltos;
    }

    public String generarReporteUsoPorGrupo() {
        StringBuilder reporte = new StringBuilder("Reporte de Uso por Grupo:\n");
        int cuerdas = 0, cuerdasFrotadas = 0, vientos = 0, metales = 0, percusion = 0;

        for (Instrumento instrumento : inventarioInstrumentos) {
            switch (instrumento.getGrupo().toLowerCase()) {
                case "cuerdas":
                    cuerdas += instrumento.getCantidad();
                    break;
                case "cuerdas frotadas":
                    cuerdasFrotadas += instrumento.getCantidad();
                    break;
                case "vientos":
                    vientos += instrumento.getCantidad();
                    break;
                case "metales":
                    metales += instrumento.getCantidad();
                    break;
                case "percusión":
                    percusion += instrumento.getCantidad();
                    break;
            }
        }

        reporte.append("Cuerdas: ").append(cuerdas).append("\n")
               .append("Cuerdas Frotadas: ").append(cuerdasFrotadas).append("\n")
               .append("Vientos: ").append(vientos).append("\n")
               .append("Metales: ").append(metales).append("\n")
               .append("Percusión: ").append(percusion).append("\n");

        return reporte.toString();
    }
}