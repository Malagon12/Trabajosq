package newpackage;

import java.util.Objects;

public class Fabricantes {
   private String nombre;
   private String pais;
   private String añoFundacion;

    public Fabricantes(String nombre, String pais, String añoFundacion) {
        this.nombre = nombre;
        this.pais = pais;
        this.añoFundacion = añoFundacion;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.nombre);
        hash = 59 * hash + Objects.hashCode(this.pais);
        hash = 59 * hash + Objects.hashCode(this.añoFundacion);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Fabricantes other = (Fabricantes) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.pais, other.pais)) {
            return false;
        }
        return Objects.equals(this.añoFundacion, other.añoFundacion);
    }

    @Override
    public String toString() {
        return "Fabricantes{" + "nombre=" + nombre + ", pais=" + pais + ", a\u00f1oFundacion=" + añoFundacion + '}';
    }
   
}
