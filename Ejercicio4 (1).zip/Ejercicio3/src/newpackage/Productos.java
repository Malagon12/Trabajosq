package newpackage;

import java.util.List;
import java.util.Objects;

public class Productos {
   private String nombre;
   private String codigo;
   private String tipo;
   private double precio;
   private List<Fabricantes>fabricantes;

    public Productos(String nombre, String codigo, String tipo, double precio, List<Fabricantes> fabricantes) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.tipo = tipo;
        this.precio = precio;
        this.fabricantes = fabricantes;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public List<Fabricantes> getFabricantes() {
        return fabricantes;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.nombre);
        hash = 89 * hash + Objects.hashCode(this.codigo);
        hash = 89 * hash + Objects.hashCode(this.tipo);
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.precio) ^ (Double.doubleToLongBits(this.precio) >>> 32));
        hash = 89 * hash + Objects.hashCode(this.fabricantes);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Productos other = (Productos) obj;
        if (Double.doubleToLongBits(this.precio) != Double.doubleToLongBits(other.precio)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.tipo, other.tipo)) {
            return false;
        }
        return Objects.equals(this.fabricantes, other.fabricantes);
    }

    @Override
    public String toString() {
        return "Productos{" + "nombre=" + nombre + ", codigo=" + codigo + ", tipo=" + tipo + ", precio=" + precio + ", fabricantes=" + fabricantes + '}';
    }
   
}
