package newpackage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Tienda {
    private List<Productos>productos;
    private List<Fabricantes>fabricantes;
    private List<Ventas>ventas;

    public Tienda(List<Productos> productos, List<Fabricantes> fabricantes, List<Ventas> ventas) {
        this.productos = new ArrayList<>();
        this.fabricantes = new ArrayList<>();
        this.ventas = new ArrayList<>();
    }
    public void agregarProductos(){
        String nombre=  JOptionPane.showInputDialog("Digite el nombre del producto");
        String codigo = JOptionPane.showInputDialog("digite el codigo del producto");
        String tipo = JOptionPane.showInputDialog("Digite el tipo del producto(Laptop, Monitor, Accesorio)");
        double precio = Double.parseDouble(JOptionPane.showInputDialog("digite el precio del producto"));
        Productos producto = new Productos(nombre, codigo, tipo, precio, fabricantes);
        productos.add(producto);
        JOptionPane.showMessageDialog(null, "Producto Agregado Exitosamente");
    }
    public void registrarFabricantes(){
       String nombre=  JOptionPane.showInputDialog("Digite el nombre del fabricante");
        String pais = JOptionPane.showInputDialog("digite el pais de la fabrica");
        String añoFundacion = JOptionPane.showInputDialog("Digite el año de fue fundada la dabrica"); 
        Fabricantes fabricante = new Fabricantes(nombre, pais, añoFundacion);
        fabricantes.add(fabricante);
        JOptionPane.showMessageDialog(null, "Fabricante Agregado Exitosamente");

    }
    public void realizarVentas(){
       String nombre = JOptionPane.showInputDialog("Digite el nombre del producto");
       double precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el preco del producto"));
       int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad del Producto"));
       LocalDate fecha = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha del producto"));
       
       Productos producto = productos.stream()
       .filter(h->h.getNombre()== nombre)
            .findFirst()
            .orElse(null);
        if (producto!=null) {
            Ventas venta = new Ventas(nombre, cantidad, fecha, precio);
            ventas.add(venta);
        JOptionPane.showMessageDialog(null, "Venta Realizada Exitosamente\n" + venta);
        }
        else{
        JOptionPane.showMessageDialog(null, "Cuidado!! Venta No Realizada");
        }
    }
      public double calcularTotalVentasEnPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        double totalVentas = 0.0;

        for (Ventas venta : ventas) {
            LocalDate fechaVenta = venta.getFecha();
            if (fechaVenta.isAfter(fechaInicio) && fechaVenta.isBefore(fechaFin)) {
                totalVentas += venta.getTotal();
            }
        }
        return totalVentas;
    }
}
