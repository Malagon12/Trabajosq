package newpackage;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public class appVentas {
    public static void main(String[] args) {
        Tienda tienda = new Tienda();
    while(true){
            String [] opciones ={
                "Agregar Producto",
                "Registrar Fabricantes",
                "Realizar Ventas",
                "Total De Ventas",
                "Salir"
            };
            String seleccion = (String)JOptionPane.showInputDialog(null, "Selecione una opcion", 
                    "Sistema de Gestión de Ventas de Computadores y Tecnología", JOptionPane.QUESTION_MESSAGE,null,
                    opciones, opciones[0]);
            if (seleccion == null || seleccion.equals("salir")) {
                break;
            }
            switch (seleccion) {
                case "Agregar Producto":
                    tienda.agregarProductos();
                    break;
                case "Registrar Fabricantes":
                    tienda.registrarFabricantes();
                    break;
                case "Realizar Ventas":
                    tienda.realizarVentas();
                    break;
                case "Total De Ventas":
                    tienda.calcularTotalVentasEnPeriodo(LocalDate.MIN, LocalDate.MIN);
                    break;
                case "Listar Reservas":
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "opcion invalida");
                    break;
            }
        }
        JOptionPane.showMessageDialog(null, "Gracias por usar el Sistema de Gestion");
    }
}
