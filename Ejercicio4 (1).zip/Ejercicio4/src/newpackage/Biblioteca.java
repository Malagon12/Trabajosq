package newpackage;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import javax.swing.JOptionPane;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Biblioteca {
    private List<Usuario> usuarios;
    private List<Prestamo> prestamos;
    private List<Libro> libros;

    public Biblioteca() {
        usuarios = new ArrayList<>();
        prestamos = new ArrayList<>();
        libros = new ArrayList<>();
    }

    public static String tipoUsuario(String mensaje) {
        String[] opciones = {"bibliotecario", "lector"};
        return (String) JOptionPane.showInputDialog(null, mensaje, "Elija una opción", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
    }
    
public boolean consultarDisponibilidadDelLibro(String isbn) {
        Libro libro = buscarLibroPorIsbn(isbn);
        if (libro != null) {
            return libro.getDisponibles() > 0;
        }
        return false; 
    }
    public boolean autenticarUsuario() {
        String identificacion = JOptionPane.showInputDialog("Ingrese la identificación del usuario:");
        String contraseña = JOptionPane.showInputDialog("Ingrese la contraseña:");
        for (Usuario usuario : usuarios) {
            if (usuario.getIdentificacion().equals(identificacion) && usuario.getContraseña().equals(hashPassword(contraseña))) {
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "Identificación o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            registrarError("Error al encriptar la contraseña: " + e.getMessage());
            return null;
        }
    }

    public void modificarUsuario() {
        String identificacion = JOptionPane.showInputDialog("Ingrese la identificación del usuario a modificar:");
        String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre:");
        String nuevoCorreo = JOptionPane.showInputDialog("Ingrese el nuevo correo electrónico:");
        String nuevaContraseña = JOptionPane.showInputDialog("Ingrese la nueva contraseña:");

        for (Usuario usuario : usuarios) {
            if (usuario.getIdentificacion().equals(identificacion)) {
                usuarios.remove(usuario);
                Usuario usuarioModificado = new Usuario(nuevoNombre, identificacion, nuevoCorreo, hashPassword(nuevaContraseña));
                usuarios.add(usuarioModificado);
                guardarDatosEnArchivo("usuarios.txt");
                JOptionPane.showMessageDialog(null, "Usuario modificado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void registrarUsuario() {

        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del usuario:");
        String id = JOptionPane.showInputDialog("Ingrese la identificación del usuario:");
        String correo = JOptionPane.showInputDialog("Ingrese el correo electrónico:");
        String contraseña = JOptionPane.showInputDialog("Ingrese la contraseña:");
        Usuario usuario = new Usuario(nombre, id, correo, hashPassword(contraseña));

        usuarios.add(usuario);
        guardarDatosEnArchivo("usuarios.txt");
        JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

public void agregarLibro() {
    String titulo = JOptionPane.showInputDialog("Ingrese el título del libro:");
    String autor = JOptionPane.showInputDialog("Ingrese el autor del libro:");
    String isbn = JOptionPane.showInputDialog("Ingrese el ISBN del libro:");
    String genero = JOptionPane.showInputDialog("Ingrese el género del libro:");
    int copias = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de copias:"));

    Libro libro = new Libro(titulo, autor, isbn, genero, copias, copias);
    libros.add(libro);
    registrarOperacionCatalogo("Añadido", libro);
    guardarDatosEnArchivo("catalogo.txt"); // Guarda después de agregar
    JOptionPane.showMessageDialog(null, "Libro agregado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    mostrarCatalogo();
}
    public void eliminarUsuario() {
        String identificacion = JOptionPane.showInputDialog("Ingrese la identificación del usuario a eliminar:");
        Iterator<Usuario> iterator = usuarios.iterator();
        while (iterator.hasNext()) {
            Usuario usuario = iterator.next();
            if (usuario.getIdentificacion().equals(identificacion)) {
                iterator.remove();
                guardarDatosEnArchivo("usuarios.txt");
                JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Usuario no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
    }
public void cargarCatalogoDesdeArchivo(String nombreArchivo) {
    try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(", ");
            if (partes.length == 6) {
                String titulo = partes[0];
                String autor = partes[1];
                String isbn = partes[2];
                String genero = partes[3];
                int copias = Integer.parseInt(partes[4]);
                int disponibles = Integer.parseInt(partes[5]);

                Libro libro = new Libro(titulo, autor, isbn, genero, copias, disponibles);
                libros.add(libro);
            }
        }
    } catch (Exception e) {
        registrarError("Error al cargar datos del catálogo desde archivo: " + e.getMessage());
    }
}
    public void realizarPrestamo() {
        String idUsuario = JOptionPane.showInputDialog("Ingrese la identificación del usuario:");
        String isbnLibro = JOptionPane.showInputDialog("Ingrese el ISBN del libro:");
        LocalDate fechaInicio = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de inicio (YYYY-MM-DD):"));
        LocalDate fechaDevolucion = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de devolución (YYYY-MM-DD):"));

        Usuario usuario = usuarios.stream()
                                  .filter(u -> u.getIdentificacion().equals(idUsuario))
                                  .findFirst()
                                  .orElse(null);

        Libro libro = buscarLibroPorIsbn(isbnLibro);

        if (usuario != null && libro != null) {
            if (libro.getDisponibles() > 0) {
                libro.prestar();
                Prestamo prestamo = new Prestamo(libro, usuario, fechaInicio, fechaDevolucion, "pendiente");
                prestamos.add(prestamo);
                registrarPrestamo(prestamo);
                JOptionPane.showMessageDialog(null, "Préstamo registrado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "El libro no está disponible para préstamo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o libro no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
public void actualizarEstadoPrestamoEnArchivo(Prestamo prestamo) {
    String archivoPrestamos = "prestamos.txt";
    String prestamoActualizado = "Usuario: " + prestamo.getUsuario().getIdentificacion() +
                                 ", ISBN: " + prestamo.getLibro().getIsbn() +
                                 ", Fecha de Préstamo: " + prestamo.getFechaInicio() +
                                 ", Fecha de Devolución: " + prestamo.getFechaDevolucion() +
                                 ", Estado: devuelto";

    try {
        // Leer todas las líneas del archivo
        List<String> lineas = Files.readAllLines(Paths.get(archivoPrestamos));

        // Reemplazar la línea correspondiente al préstamo
        List<String> lineasActualizadas = lineas.stream()
            .map(linea -> {
                if (linea.contains(prestamo.getUsuario().getIdentificacion()) && 
                    linea.contains(prestamo.getLibro().getIsbn()) && 
                    linea.contains("pendiente")) {
                    return prestamoActualizado;  // Actualiza la línea
                }
                return linea;  // Deja las demás líneas igual
            })
            .collect(Collectors.toList());

        // Escribir las líneas actualizadas en el archivo
        Files.write(Paths.get(archivoPrestamos), lineasActualizadas);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error al actualizar el archivo de préstamos: " + e.getMessage());
    }
}
    public boolean devolverLibro() {
    String idUsuario = JOptionPane.showInputDialog("Ingrese la identificación del usuario:");
    String ISBN = JOptionPane.showInputDialog("Ingrese el ISBN del libro:");
    String fechaDevolucionStr = JOptionPane.showInputDialog("Ingrese la fecha de devolución (yyyy-MM-dd):");

    LocalDate fechaDevolucion;
    try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        fechaDevolucion = LocalDate.parse(fechaDevolucionStr, formatter);
    } catch (DateTimeParseException e) {
        JOptionPane.showMessageDialog(null, "Formato de fecha incorrecto.");
        return false;
    }

    try {
        Prestamo prestamo = null;
        for (Prestamo p : prestamos) {
            if (p.getLibro().getIsbn().equals(ISBN) &&
                p.getUsuario().getIdentificacion().equals(idUsuario) &&
                p.getEstado().equals("pendiente")) {
                prestamo = p;
                break;
            }
        }

        if (prestamo == null) {
            JOptionPane.showMessageDialog(null, "No se encontró un préstamo activo para el libro y usuario proporcionados.");
            return false;
        }

        prestamo.marcarComoDevuelto();

        Libro libro = prestamo.getLibro();
        if (libro != null) {
            libro.incrementarConteo();  // Incrementa el conteo de préstamos devueltos
            libro.devolver();           // Incrementa el número de copias disponibles
        }

        for (Libro l : libros) {
            if (l.getIsbn().equals(ISBN)) {
                l.setDisponibles(libro.getDisponibles()); // Actualiza el número de copias disponibles en el catálogo
                l.setConteo(libro.getConteo());           // Actualiza el conteo de préstamos devueltos en el catálogo
                break;
            }
        }
        actualizarEstadoPrestamoEnArchivo(prestamo);

        JOptionPane.showMessageDialog(null, "Devolución realizada con éxito.");
        return true;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al procesar la devolución: " + e.getMessage());
        return false;
    }
}

    private void actualizarCatalogo() throws IOException {
        try (FileWriter fw = new FileWriter("catalogo.txt");
             BufferedWriter bw = new BufferedWriter(fw)) {
            for (Libro l : libros) {
                bw.write(String.format("%s,%s,%s,%s,%d,%d%n", l.getTitulo(), l.getAutor(), l.getIsbn(), l.getGenero(), l.getCopias(), l.getDisponibles()));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el catálogo: " + e.getMessage());
        }
    }
    public void renovarPrestamo() {
        String isbnLibro = JOptionPane.showInputDialog("Ingrese el ISBN del libro:");
        Prestamo prestamo = prestamos.stream()
                                      .filter(p -> p.getLibro().getIsbn().equals(isbnLibro) && p.getEstado().equals("pendiente"))
                                      .findFirst()
                                      .orElse(null);

        if (prestamo != null) {
            LocalDate nuevaFechaDevolucion = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la nueva fecha de devolución (YYYY-MM-DD):"));
            if (nuevaFechaDevolucion.isAfter(prestamo.getFechaDevolucion())) {
                prestamo.setFechaDevolucion(nuevaFechaDevolucion);
                JOptionPane.showMessageDialog(null, "Préstamo renovado hasta " + nuevaFechaDevolucion, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "La nueva fecha de devolución debe ser posterior a la fecha actual.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Préstamo no encontrado o ya devuelto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void generarReporteUsuariosMasActivos() {
        List<Usuario> listaUsuarios = new ArrayList<>();
        for (Prestamo prestamo : prestamos) {
            Usuario usuario = prestamo.getUsuario();
            boolean encontrado = false;
            for (Usuario uc : listaUsuarios) {
                if (uc.getNombre().equals(usuario.getNombre())) {
                    uc.incrementarConteo();
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                listaUsuarios.add(usuario);
            }
        }
        StringBuilder reporte = new StringBuilder("Reporte de Usuarios Más Activos:\n");
        for (Usuario usuario : listaUsuarios) {
            reporte.append(String.format("Nombre: %s, ID: %s, Préstamos: %d%n",
                    usuario.getNombre(), usuario.getIdentificacion(), usuario.getConteo()));
        }
        JOptionPane.showMessageDialog(null, reporte.toString(), "Reporte de Usuarios Más Activos", JOptionPane.INFORMATION_MESSAGE);
        guardarReporteEnArchivo("usuariosMasActivos.txt", reporte.toString());
    }

    public void reporteLibrosMasPrestados() {
        List<Libro> listaLibros = new ArrayList<>();
        for (Prestamo prestamo : prestamos) {
            Libro libro = prestamo.getLibro();
            boolean encontrado = false;
            for (Libro lL : listaLibros) {
                if (lL.getTitulo().equals(libro.getTitulo())) {
                    lL.incrementarConteo();
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                listaLibros.add(libro);
            }
        }
        StringBuilder reporte = new StringBuilder("Reporte de Libros Más Prestados:\n");
        for (Libro libro : listaLibros) {
            reporte.append(String.format("Título: %s, ISBN: %s, Autor: %s, Préstamos: %d%n",
                    libro.getTitulo(), libro.getIsbn(), libro.getAutor(), libro.getConteo()));
        }
        JOptionPane.showMessageDialog(null, reporte.toString(), "Reporte de Libros Más Prestados", JOptionPane.INFORMATION_MESSAGE);
        guardarReporteEnArchivo("librosMasPrestados.txt", reporte.toString());
    }

    private void guardarReporteEnArchivo(String nombreArchivo, String contenido) {
        try (FileWriter fw = new FileWriter(nombreArchivo);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(contenido);
            JOptionPane.showMessageDialog(null, "Reporte guardado en " + nombreArchivo, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            registrarError("Error al guardar el archivo: " + e.getMessage());
        }
    }

    private void registrarError(String mensajeError) {
        try (FileWriter fw = new FileWriter("errores.txt", true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(LocalDate.now() + " - " + mensajeError);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void registrarOperacionCatalogo(String operacion, Libro libro) {
        try (FileWriter fw = new FileWriter("logs/catalogoLog.txt", true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(LocalDate.now() + " - " + operacion + " - " + libro.getTitulo() + " - ISBN: " + libro.getIsbn());
        } catch (Exception e) {
            registrarError("Error al registrar operación de catálogo: " + e.getMessage());
        }
    }

    private void registrarPrestamo(Prestamo prestamo) {
        try (FileWriter fw = new FileWriter("prestamos.txt", true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(prestamo.getLibro().getTitulo() + ", " +
                       prestamo.getUsuario().getIdentificacion() + ", " +
                       prestamo.getFechaInicio() + ", " +
                       prestamo.getFechaDevolucion() + ", " +
                       prestamo.getEstado());
        } catch (Exception e) {
            registrarError("Error al registrar préstamo: " + e.getMessage());
        }
    }

    private void guardarDatosEnArchivo(String nombreArchivo) {
    try (FileWriter fw = new FileWriter(nombreArchivo);
         PrintWriter pw = new PrintWriter(fw)) {
        if (nombreArchivo.equals("usuarios.txt")) {
            for (Usuario usuario : usuarios) {
                pw.println(usuario.getNombre() + ", " +
                           usuario.getIdentificacion() + ", " +
                           usuario.getCorreoElectronico() + ", " +
                           usuario.getContraseña());
            }
        } else if (nombreArchivo.equals("catalogo.txt")) {
            for (Libro libro : libros) {
                pw.println(libro.getTitulo() + ", " +
                           libro.getAutor() + ", " +
                           libro.getIsbn() + ", " +
                           libro.getGenero() + ", " +
                           libro.getCopias() + ", " +
                           libro.getDisponibles());
            }
        }
    } catch (Exception e) {
        registrarError("Error al guardar datos en archivo: " + e.getMessage());
    }
}

public void mostrarCatalogo() {
     cargarCatalogoDesdeArchivo("catalogo.txt");

    // Verificamos si la lista de libros no está vacía
    if (libros.isEmpty()) {
        JOptionPane.showMessageDialog(null, "El catálogo está vacío.", "Información", JOptionPane.INFORMATION_MESSAGE);
    } else {
        StringBuilder catalogo = new StringBuilder();
        for (Libro libro : libros) {
            catalogo.append("Título: ").append(libro.getTitulo()).append("\n")
                    .append("Autor: ").append(libro.getAutor()).append("\n")
                    .append("ISBN: ").append(libro.getIsbn()).append("\n")
                    .append("Género: ").append(libro.getGenero()).append("\n")
                    .append("Copias Disponibles: ").append(libro.getDisponibles()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, catalogo.toString(), "Catálogo de Libros", JOptionPane.INFORMATION_MESSAGE);
    }
}
    private Libro buscarLibroPorIsbn(String isbn) {
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }
}
