
package newpackage;

import java.util.Objects;

   public class Libro {
    private String titulo;
    private String autor;
    private String isbn;
    private String genero;
    private int copias;
    private int disponibles;
    private int conteo;

    public int getConteo() {
        return conteo;
    }

    public Libro(String titulo, String autor, String isbn, String genero, int copias, int conteo) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.genero = genero;
        this.copias = copias;
        this.disponibles = copias;
        this.conteo=0;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getGenero() {
        return genero;
    }

    public int getCopias() {
        return copias;
    }

    public int getDisponibles() {
        return disponibles;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setCopias(int copias) {
        this.copias = copias;
    }

    public void setDisponibles(int disponibles) {
        this.disponibles = disponibles;
    }

    public void setConteo(int conteo) {
        this.conteo = conteo;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + Objects.hashCode(this.titulo);
        hash = 23 * hash + Objects.hashCode(this.autor);
        hash = 23 * hash + Objects.hashCode(this.isbn);
        hash = 23 * hash + Objects.hashCode(this.genero);
        hash = 23 * hash + this.copias;
        hash = 23 * hash + this.disponibles;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Libro other = (Libro) obj;
        if (this.copias != other.copias) {
            return false;
        }
        if (this.disponibles != other.disponibles) {
            return false;
        }
        if (!Objects.equals(this.titulo, other.titulo)) {
            return false;
        }
        if (!Objects.equals(this.autor, other.autor)) {
            return false;
        }
        if (!Objects.equals(this.isbn, other.isbn)) {
            return false;
        }
        return Objects.equals(this.genero, other.genero);
    }

    @Override
    public String toString() {
        return "Libro{" + "titulo=" + titulo + ", autor=" + autor + ", isbn=" + isbn + ", genero=" + genero + ", copias=" + copias + ", disponibles=" + disponibles + '}';
    }

    public void prestar() {
        if (disponibles > 0) {
            disponibles--;
        }
    }

    public void devolver() {
        if (disponibles < copias) {
            disponibles++;
        }
    }
    public void incrementarConteo() {
            conteo++;
        }
}
