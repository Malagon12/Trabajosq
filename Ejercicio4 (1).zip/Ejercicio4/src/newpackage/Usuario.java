package newpackage;

import java.util.Objects;
import javax.swing.JOptionPane;

public class Usuario {
    private String nombre;
    private String identificacion;
    private String correoElectronico;
    private String contraseña; 
    private int conteo;

    public Usuario(String nombre, String identificacion, String correoElectronico, String contraseña) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.correoElectronico = correoElectronico;
        this.contraseña = contraseña; 
        this.conteo = 0; 
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }
   

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public int getConteo() {
        return conteo;
    }

    public void setConteo(int conteo) {
        this.conteo = conteo;
    }

    public void incrementarConteo() {
        this.conteo++;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, identificacion,  correoElectronico);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Usuario other = (Usuario) obj;
        return Objects.equals(nombre, other.nombre) &&
               Objects.equals(identificacion, other.identificacion) &&
               Objects.equals(correoElectronico, other.correoElectronico);
    }

    @Override
    public String toString() {
        return "Usuario{" +
               "nombre='" + nombre + '\'' +
               ", identificacion='" + identificacion + '\'' +
               ", correoElectronico='" + correoElectronico + '\'' +
               ", conteo=" + conteo +
               '}';
    }
    
}
