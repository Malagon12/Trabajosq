package newpackage;

import javax.swing.JOptionPane;

public class appBiblioteca {

    public static void mostrarMenuBibliotecario(Biblioteca biblioteca) {
        while (true) {
            String[] opciones = {
                "Agregar Libros",
                "Registrar Préstamo",
                "Agregar Usuario",
                "Eliminar Usuario",
                "Consultar Disponibilidad del Libro",
                "Salir"
            };
            String seleccion = (String) JOptionPane.showInputDialog(null, "Seleccione una opción: ",
                    "Menú Bibliotecario", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (seleccion == null || "Salir".equals(seleccion)) {
                break;
            }
            switch (seleccion) {
                case "Registrar Préstamo":
                    biblioteca.realizarPrestamo();
                    break;
                case "Agregar Usuario":
                    biblioteca.registrarUsuario();
                    break;
                case "Eliminar Usuario":
                    biblioteca.eliminarUsuario();
                    break;
                case "Consultar Disponibilidad del Libro":
                    String isbnLibroConsultar = JOptionPane.showInputDialog("Ingrese ISBN del libro:");
                    boolean disponible = biblioteca.consultarDisponibilidadDelLibro(isbnLibroConsultar);
                    JOptionPane.showMessageDialog(null, disponible ? "El libro está disponible." : "El libro no está disponible.", "Disponibilidad del Libro", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "Agregar Libros":
                biblioteca.agregarLibro();
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
        JOptionPane.showMessageDialog(null, "Gracias por usar el sistema");
    }

    public static void mostrarMenuLector(Biblioteca biblioteca) {
        while (true) {
            String[] opciones = {
                "Consultar Catálogo",
                "Solicitar Préstamo",
                "Devolver Libro",
                "Salir"
            };
            String seleccion = (String) JOptionPane.showInputDialog(null, "Seleccione una opción: ",
                    "Menú Lector", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (seleccion == null || "Salir".equals(seleccion)) {
                break;
            }
            switch (seleccion) {
                case "Consultar Catálogo":
                    biblioteca.mostrarCatalogo();
                    break;
                case "Solicitar Préstamo":
                    biblioteca.realizarPrestamo();
                    break;
                case "Devolver Libro":
                    biblioteca.devolverLibro();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
        JOptionPane.showMessageDialog(null, "Gracias por usar el sistema");
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
            String tipo = (JOptionPane.showInputDialog("Ingrese su rol:"));
            if ("bibliotecario".equalsIgnoreCase(tipo)) {
                mostrarMenuBibliotecario(biblioteca);
            } else if ("lector".equalsIgnoreCase(tipo)) {
                mostrarMenuLector(biblioteca);
            }
         else {
            JOptionPane.showMessageDialog(null, "Identificación o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
